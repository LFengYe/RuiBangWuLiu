/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cn.bean.report;

/**
 *
 * @author LFeng
 */
public class RKListForBLpRK {

    private String blpRkTime;
    private String outInType;
    private String outInMethod;
    private String supplierID;
    private String supplierName;
    private String partCode;
    private String partName;
    private String partID;
    private String inboundBatch;
    private String blpRKAmount;
    private String inspectorName;
    private String inspectionReportListRemark;

    public String getBlpRkTime() {
        return blpRkTime;
    }

    public void setBlpRkTime(String blpRkTime) {
        this.blpRkTime = blpRkTime;
    }

    public String getOutInType() {
        return outInType;
    }

    public void setOutInType(String outInType) {
        this.outInType = outInType;
    }

    public String getOutInMethod() {
        return outInMethod;
    }

    public void setOutInMethod(String outInMethod) {
        this.outInMethod = outInMethod;
    }

    public String getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(String supplierID) {
        this.supplierID = supplierID;
    }

    public String getSupplierName() {
        return supplierName;
    }

    public void setSupplierName(String supplierName) {
        this.supplierName = supplierName;
    }

    public String getPartCode() {
        return partCode;
    }

    public void setPartCode(String partCode) {
        this.partCode = partCode;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }

    public String getPartID() {
        return partID;
    }

    public void setPartID(String partID) {
        this.partID = partID;
    }

    public String getInboundBatch() {
        return inboundBatch;
    }

    public void setInboundBatch(String inboundBatch) {
        this.inboundBatch = inboundBatch;
    }

    public String getBlpRKAmount() {
        return blpRKAmount;
    }

    public void setBlpRKAmount(String blpRKAmount) {
        this.blpRKAmount = blpRKAmount;
    }

    public String getInspectorName() {
        return inspectorName;
    }

    public void setInspectorName(String inspectorName) {
        this.inspectorName = inspectorName;
    }

    public String getInspectionReportListRemark() {
        return inspectionReportListRemark;
    }

    public void setInspectionReportListRemark(String inspectionReportListRemark) {
        this.inspectionReportListRemark = inspectionReportListRemark;
    }
}
