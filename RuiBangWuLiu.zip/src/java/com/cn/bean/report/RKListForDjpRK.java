/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cn.bean.report;

/**
 *
 * @author LFeng
 */
public class RKListForDjpRK {

    private String djRKProduceTime;
    private String djInWareHouseID;
    private String outInType;
    private String outInWethod;
    private String partCode;
    private String partID;
    private String partName;
    private String inboundBatch;
    private String djRKAmount;
    private String djRKProducerName;
    private String djInWareHouseListRemark;

    public String getDjRKProduceTime() {
        return djRKProduceTime;
    }

    public void setDjRKProduceTime(String djRKProduceTime) {
        this.djRKProduceTime = djRKProduceTime;
    }

    public String getDjInWareHouseID() {
        return djInWareHouseID;
    }

    public void setDjInWareHouseID(String djInWareHouseID) {
        this.djInWareHouseID = djInWareHouseID;
    }

    public String getOutInType() {
        return outInType;
    }

    public void setOutInType(String outInType) {
        this.outInType = outInType;
    }

    public String getOutInWethod() {
        return outInWethod;
    }

    public void setOutInWethod(String outInWethod) {
        this.outInWethod = outInWethod;
    }

    public String getPartCode() {
        return partCode;
    }

    public void setPartCode(String partCode) {
        this.partCode = partCode;
    }

    public String getInboundBatch() {
        return inboundBatch;
    }

    public void setInboundBatch(String inboundBatch) {
        this.inboundBatch = inboundBatch;
    }

    public String getDjRKAmount() {
        return djRKAmount;
    }

    public void setDjRKAmount(String djRKAmount) {
        this.djRKAmount = djRKAmount;
    }

    public String getDjRKProducerName() {
        return djRKProducerName;
    }

    public void setDjRKProducerName(String djRKProducerName) {
        this.djRKProducerName = djRKProducerName;
    }

    public String getDjInWareHouseListRemark() {
        return djInWareHouseListRemark;
    }

    public void setDjInWareHouseListRemark(String djInWareHouseListRemark) {
        this.djInWareHouseListRemark = djInWareHouseListRemark;
    }

    public String getPartID() {
        return partID;
    }

    public void setPartID(String partID) {
        this.partID = partID;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }
}
