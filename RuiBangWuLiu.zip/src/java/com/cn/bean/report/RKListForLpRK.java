/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.cn.bean.report;

/**
 *
 * @author LFeng
 */
public class RKListForLpRK {

    private String lpRKTime;
    private String outInType;
    private String outInWethod;
    private String partCode;
    private String partID;
    private String partName;
    private String inboundBatch;
    private String lpRKAmount;
    private String lpRKProducerName;
    private String lpRKListRemark;

    public String getLpRKTime() {
        return lpRKTime;
    }

    public void setLpRKTime(String lpRKTime) {
        this.lpRKTime = lpRKTime;
    }

    public String getOutInType() {
        return outInType;
    }

    public void setOutInType(String outInType) {
        this.outInType = outInType;
    }

    public String getOutInWethod() {
        return outInWethod;
    }

    public void setOutInWethod(String outInWethod) {
        this.outInWethod = outInWethod;
    }

    public String getPartCode() {
        return partCode;
    }

    public void setPartCode(String partCode) {
        this.partCode = partCode;
    }

    public String getInboundBatch() {
        return inboundBatch;
    }

    public void setInboundBatch(String inboundBatch) {
        this.inboundBatch = inboundBatch;
    }

    public String getLpRKAmount() {
        return lpRKAmount;
    }

    public void setLpRKAmount(String lpRKAmount) {
        this.lpRKAmount = lpRKAmount;
    }

    public String getLpRKProducerName() {
        return lpRKProducerName;
    }

    public void setLpRKProducerName(String lpRKProducerName) {
        this.lpRKProducerName = lpRKProducerName;
    }

    public String getLpRKListRemark() {
        return lpRKListRemark;
    }

    public void setLpRKListRemark(String lpRKListRemark) {
        this.lpRKListRemark = lpRKListRemark;
    }

    public String getPartID() {
        return partID;
    }

    public void setPartID(String partID) {
        this.partID = partID;
    }

    public String getPartName() {
        return partName;
    }

    public void setPartName(String partName) {
        this.partName = partName;
    }
}
